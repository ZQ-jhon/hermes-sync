---
name: genkit-openrouter-app
description: Build a Genkit JS (TypeScript) app backed by an OpenAI-compatible provider such as OpenRouter — proxying Claude/other models via @genkit-ai/compat-oai. Covers project init, structured output flows, passing OpenRouter-only config (provider routing), and the non-obvious Node-fetch-ignores-system-proxy region-403 trap. Use when setting up Genkit with OpenRouter/Claude, or debugging "This model is not available in your region" 403s.
---

# Genkit + OpenRouter (OpenAI-compatible) app

Set up Genkit JS to call Claude (or any model) through OpenRouter's OpenAI-compatible
endpoint. Official docs: https://genkit.dev/docs/js/get-started/ and
https://genkit.dev/docs/integrations/openai-compatible/

## Setup

```bash
npm install genkit @genkit-ai/compat-oai dotenv
npm install -D @types/node tsx typescript
# remove google-genai if you scaffolded from the Gemini quickstart:
npm uninstall @genkit-ai/google-genai
```

Minimal wiring (the import name is `compatOaiModelRef`, NOT `modelRef` as some docs show):

```ts
import 'dotenv/config';
import { genkit, z } from 'genkit';
import { openAICompatible, compatOaiModelRef } from '@genkit-ai/compat-oai';

const ai = genkit({
  plugins: [openAICompatible({
    name: 'openrouter',
    apiKey: process.env.OPENROUTER_API_KEY,
    baseURL: 'https://openrouter.ai/api/v1',
  })],
});

const claude = compatOaiModelRef({ name: 'openrouter/anthropic/claude-sonnet-4.5' });
```

- Model id format: `openrouter/<vendor>/<model>` (plugin name `/` OpenRouter model id).
- Structured output: pass `output: { schema: ZodSchema }` to `ai.generate(...)`; the plugin
  emits `response_format: json_schema`.
- Put `OPENROUTER_API_KEY` in `.env` (gitignored), ship a committable `.env.example`.
- Key from https://openrouter.ai/keys . Run with `node --import tsx src/index.ts`.

## tsconfig gotchas
If `tsconfig.json` has `verbatimModuleSyntax: true`, `module: nodenext`, `target: esnext`:
- using `process.env` requires `"types": ["node"]` AND `npm i -D @types/node`, else TS errors.
- Do NOT run `npx tsc --noEmit src/index.ts` (filenames on the CLI ignore tsconfig → TS5112).
  Run bare `npx tsc --noEmit` so the project config loads.

## Pitfall 1 — Node built-in fetch ignores HTTP(S)_PROXY → region 403 (THE BIG ONE)
Symptom: `403 This model is not available in your region.` from Genkit, while `curl` and
Python to the *same* endpoint with the *same* body/key succeed. Anthropic models on
OpenRouter are region-gated; some networks need a local proxy (Clash etc.) to reach an
allowed exit IP.

Root cause: **Node.js built-in `fetch` (undici) does NOT read `HTTP_PROXY`/`HTTPS_PROXY`
env vars** — it connects directly, so its exit IP lands in the blocked region even though
your shell tools go through the proxy. This masquerades as a model-name / API-key / account
problem; it is a transport problem.

Fix — give Genkit a proxy-aware fetch via undici `ProxyAgent`:
```bash
npm install undici
```
```ts
import { ProxyAgent } from 'undici';
const proxyUrl = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
const proxyFetch: any = proxyUrl
  ? (input: any, init?: any) =>
      fetch(input, { ...init, dispatcher: new ProxyAgent(proxyUrl) } as any)
  : fetch;

openAICompatible({ name: 'openrouter', apiKey: ..., baseURL: ..., fetch: proxyFetch });
```
Type note: the plugin's `fetch` type is narrower than the global; declare `proxyFetch: any`
to avoid a TS2322 mismatch (functional, harmless to widen).

Diagnose before fixing — compare exit IPs (see scripts/diagnose-region-403.sh):
`curl https://api.ipify.org` vs `node -e "fetch('https://api.ipify.org').then(r=>r.text()).then(console.log)"`.
If curl shows an allowed IP and Node `fetch failed`/shows a different IP → it's the proxy gap.

## Pitfall 2 — model 403 is sometimes the model, not the region
`anthropic/claude-sonnet-4` (older) was region-blocked outright in one case while
`claude-sonnet-4.5` routed to Amazon Bedrock and worked. Before deep debugging, try a newer
model id. Use scripts/diagnose-region-403.sh to probe which Claude ids actually answer.

## Pitfall 3 — OpenRouter-only config fields (e.g. `provider` routing) get stripped
Genkit validates `config` against the model's Zod `configSchema` and DROPS unknown keys, so
OpenRouter extensions like `provider: { order: [...], allow_fallbacks: false }` never reach
the request body. To pass them, give `compatOaiModelRef` a custom `configSchema` that
`.passthrough()`es and declares the field:
```ts
const schema = z.object({ provider: z.any().optional() }).passthrough();
compatOaiModelRef({ name: '...', configSchema: schema });
```
The plugin DOES splat unknown config into the request body (`{...body, ...restOfConfig}` in
node_modules/@genkit-ai/compat-oai/lib/model.js `toOpenAIRequestBody`) — the only gate is the
schema. NOTE: in the region-403 case above, provider routing was a red herring; the real fix
was the proxy. Reach for passthrough config only when you genuinely need an OpenRouter-only
parameter.

## Verification
- `npx tsc --noEmit` → exit 0.
- `node --import tsx src/index.ts` → prints the structured object.
- See references/openrouter-region-403-debug.md for the full elimination path that proved
  body/headers/UA/stream were NOT the cause, only the proxy.
